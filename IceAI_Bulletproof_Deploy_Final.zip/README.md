# IceAI Dashboard

Instructions will be added here.
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR_USERNAME/IceAI-Dashboard)

## Setup Instructions

1. Click the button above to deploy instantly to Render.
2. Set the following environment variables in the Render dashboard:
    - `DISCORD_CLIENT_ID`
    - `DISCORD_CLIENT_SECRET`
    - `DISCORD_REDIRECT_URI`
    - `SECRET_KEY`
    - `SELLHUB_SECRET` (optional, for premium users)
3. Wait for the build and deployment process to finish.
4. Open your live dashboard from the provided Render URL.
